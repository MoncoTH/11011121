package com.example.bmr_lab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class BMR extends AppCompatActivity {

    private String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmr);

        Intent intent = getIntent();
        message = intent.getStringExtra(MainActivity.BMI_MSG);
        message = getString(R.string.BMRshow) + " " + message + " " + getString(R.string.Calories);
        TextView textView = findViewById(R.id.BMRView);
        textView.setTextSize(25);
        textView.setText(message);
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.share, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, message);
        startActivity(Intent.createChooser(intent, getText(R.string.shareto)));
        return super.onOptionsItemSelected(item);
    }
}