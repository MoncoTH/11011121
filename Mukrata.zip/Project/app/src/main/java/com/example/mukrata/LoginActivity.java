package com.example.mukrata;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

}
