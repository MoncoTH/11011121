package com.example.mukrata;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class ResgisterActivity extends AppCompatActivity {

    private TextInputEditText userNameEdt,pwdEdt,cmfPwdEdt;
    private Button registerBtn;
    private ProgressBar loadingPB;
    private TextView loginTV;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resgister);

        userNameEdt = findViewById(R.id.idEditUserName);
        pwdEdt = findViewById(R.id.idEditPassword);
        cmfPwdEdt = findViewById(R.id.idEditCnfPassword);
        registerBtn = findViewById(R.id.idBtnRegister);
        loadingPB = findViewById(R.id.idPBloadin);
        loginTV = findViewById(R.id.idTVLogin);
        mAuth = FirebaseAuth.getInstance();
        loginTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ResgisterActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingPB.setVisibility(View.VISIBLE);
                String userName = userNameEdt.getText().toString();
                String pwd = pwdEdt.getText().toString();
                String cntPwd = cmfPwdEdt.getText().toString();

                if (!pwd.equals(cntPwd)){
                    Toast.makeText(ResgisterActivity.this, "Please chek Password!", Toast.LENGTH_LONG).show();
                }else if(TextUtils.isEmpty(userName) && TextUtils.isEmpty(pwd) && TextUtils.isEmpty(cntPwd)){
                    Toast.makeText(ResgisterActivity.this, "Please Add your credentials..", Toast.LENGTH_LONG).show();
                }else {
                    mAuth.createUserWithEmailAndPassword(userName,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                loadingPB.setVisibility(View.GONE);
                                Toast.makeText(ResgisterActivity.this, "User Registered..", Toast.LENGTH_LONG).show();
                                Intent i = new Intent(ResgisterActivity.this, LoginActivity.class);
                                startActivity(i);
                                finish();
                            }
                            else {
                                loadingPB.setVisibility(View.GONE);
                                Toast.makeText(ResgisterActivity.this, "Fail to register user...", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                }
            }
        });
    }
}