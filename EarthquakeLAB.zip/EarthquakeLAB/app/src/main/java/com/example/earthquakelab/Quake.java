package com.example.earthquakelab;

import android.annotation.SuppressLint;
import android.location.Location;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Quake {
    private Date date;
    private String details;
    private Location location;
    private double depth;
    private double magnitude;
    private String link;
    public Date getDate() { return date; }
    public String getDetails() { return details; }
    public Location getLocation() { return location; }
    public double getMagnitude() { return magnitude; }
    public String getLink() { return link; }
    public Quake(Date _d, String _det, Location _loc, double _mag, String _link, double depth) {
        date = _d;
        details = _det;
        location = _loc;
        magnitude = _mag;
        link = _link;
        this.depth = depth;
    }
    @SuppressLint("DefaultLocale")
    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy, HH.mm", Locale.US);
        String dateString = sdf.format(date);
        DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("#.##########", otherSymbols);
        return String.format("%s: %.1f (%sm) %s",dateString,magnitude,df.format(depth),details);
    }

}
