package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class BMR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        Intent intent = getIntent();
        String result = intent.getStringExtra(MainActivity.BMI_MSG);
        String message;
        message = getString(R.string.BMRshow) + " " + result + " " + getString(R.string.Calories);
        TextView textView = (TextView) findViewById(R.id.BMRView);
        textView.setTextSize(24);
        textView.setText(message);
    }
}