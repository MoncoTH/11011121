package com.example.bmi;

import static java.lang.Double.parseDouble;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    int age;
    int height;
    int weight;
    public static final String BMI_MSG = "com.example.bmi.MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Exerciselist, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

    }


    public void calculate(View view) {
        Intent intent = new Intent(MainActivity.this, BMR.class);

        EditText ageEditText,heightEditText,weightEditText;
            ageEditText = (EditText) findViewById(R.id.Age);
            heightEditText = (EditText) findViewById(R.id.Height);
            weightEditText = (EditText) findViewById(R.id.Weight);

        age = Integer.parseInt(ageEditText.getText().toString());
        height = Integer.parseInt((heightEditText.getText().toString()));
        weight = Integer.parseInt(weightEditText.getText().toString());

        float result = (float) ((10 * weight) + (6.25 * height) + (5 * age));

        RadioButton maleradiobutton = findViewById(R.id.radio1);
        RadioButton femaleradiobutton = findViewById(R.id.radio2);

        if(maleradiobutton.isChecked()){
            result += 5;
        }else if (femaleradiobutton.isChecked()){
            result -= 161;
        }
        Spinner spiner = findViewById(R.id.spinner);

        int id = (int) spiner.getSelectedItemId();

        switch (id){
            case 0 :
                result = 1.2F * result;
                break;
            case 1 :
                result = 1.375F * result;
                break;
            case 2 :
                result = 1.55F * result;
                break;
            case 3 :
                result = 1.725F * result;
                break;
            case 4 :
                result = 1.9F * result;
                break;
        }
        intent.putExtra(BMI_MSG,String.format("%.3f",result));
        startActivity(intent);
    }
}