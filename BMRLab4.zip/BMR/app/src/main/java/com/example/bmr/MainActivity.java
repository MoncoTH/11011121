package com.example.bmr;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.example.bmr.database.BMRDatabaseHelper;
import com.example.bmr.database.BMRHistory;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private BMRDatabaseHelper bmrDatabaseHelper = new BMRDatabaseHelper(this);
    public static String BMR_RESULT = "com.example.BMR_RESULT";
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.exerciseSpinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.exerciseSpinner, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        if(loadStringPreferences("gender").equals("male")){
            ((RadioButton)findViewById(R.id.radioButtonMale)).setChecked(true);
        }else if(loadStringPreferences("gender").equals("female")){
            ((RadioButton)findViewById(R.id.radioButtonFemale)).setChecked(true);
        }

        ((EditText)findViewById(R.id.editTextAge)).setText(String.valueOf(loadIntPreferences("age")));
        ((EditText)findViewById(R.id.editTextHeight)).setText(String.valueOf(loadIntPreferences("height")));
        ((EditText)findViewById(R.id.editTextWeight)).setText(String.valueOf(loadIntPreferences("weight")));

        ((Spinner)findViewById(R.id.exerciseSpinner)).setSelection(loadIntPreferences("exercise"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    protected void onStop() {
        savePreferences();
        super.onStop();
    }

    public void onClickCalculate(View view){
        Intent intent = new Intent(this,DisplayResultActivity.class);

        EditText editTextAge = findViewById(R.id.editTextAge);
        EditText editTextHeight = findViewById(R.id.editTextHeight);
        EditText editTextWeight = findViewById(R.id.editTextWeight);

        int age = !editTextAge.getText().toString().equals("") ?  Integer.parseInt(editTextAge.getText().toString()) : 0;
        int height = !editTextHeight.getText().toString().equals("") ? Integer.parseInt(editTextHeight.getText().toString()) : 0;
        int weight = !editTextWeight.getText().toString().equals("") ?  Integer.parseInt(editTextWeight.getText().toString()) : 0;

        RadioButton radioButtonMale = findViewById(R.id.radioButtonMale);
        RadioButton radioButtonFemale = findViewById(R.id.radioButtonFemale);

        float result = (10 * weight) + (6.25F * height) + (5 * age);
        if (radioButtonMale.isChecked()){
            result += 5;
        }else if(radioButtonFemale.isChecked()){
            result -= 161;
        }

        Spinner spinner = findViewById(R.id.exerciseSpinner);
        int id = (int) spinner.getSelectedItemId();

        switch(id){
            case 0:
                result = 1.2F * result;
                break;
            case 1:
                result = 1.375F * result;
                break;
            case 2:
                result = 1.55F * result;
                break;
            case 3:
                result = 1.725F * result;
                break;
            case 4:
                result = 1.9F * result;
                break;
        }

        savePreferences();

        intent.putExtra(BMR_RESULT,String.format("%.2f",result));
        startActivity(intent);
    }

    private void savePreferences(){
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        if(((RadioButton)(findViewById(R.id.radioButtonMale))).isChecked()){
            editor.putString("gender","male");
        }else if(((RadioButton)(findViewById(R.id.radioButtonFemale))).isChecked()){
            editor.putString("gender","female");
        }

        editor.putInt("age",Integer.parseInt(((EditText)findViewById(R.id.editTextAge)).getText().toString()));
        editor.putInt("height",Integer.parseInt(((EditText)findViewById(R.id.editTextHeight)).getText().toString()));
        editor.putInt("weight",Integer.parseInt(((EditText)findViewById(R.id.editTextWeight)).getText().toString()));
        editor.putInt("exercise",(int) ((Spinner)findViewById(R.id.exerciseSpinner)).getSelectedItemId());
        editor.apply();
    }

    private void clearPreference(){
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        clearItem();
    }

    private void clearItem(){
        ((RadioButton)findViewById(R.id.radioButtonMale)).setChecked(false);
        ((RadioButton)findViewById(R.id.radioButtonFemale)).setChecked(false);
        ((EditText)findViewById(R.id.editTextAge)).setText("");
        ((EditText)findViewById(R.id.editTextHeight)).setText("");
        ((EditText)findViewById(R.id.editTextWeight)).setText("");
        ((Spinner)findViewById(R.id.exerciseSpinner)).setSelection(0);
    }

    private String loadStringPreferences(String name){

        return sharedPreferences.getString(name,"");

    }

    private int loadIntPreferences(String name){
        return sharedPreferences.getInt(name,0);
    }

    public void onClickHistory(MenuItem menuItem){
        showDialogMessage(bmrDatabaseHelper.getAllBMRData());
    }

    public void showDialogMessage(List<BMRHistory> bmrHistoryList){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(getString(R.string.historydetails));

        String message= "";
        for(int i = bmrHistoryList.size()-1; i >= 0;i--){
            String message1 = String.format("\n %s: %s \n %s: %.2f\n",getString(R.string.time),bmrHistoryList.get(i).getDatetime(),getString(R.string.bmr),bmrHistoryList.get(i).getBmr());
            message = String.format("%s %s",message,message1);
        }

        builder.setMessage(message);
        builder.show();
    }

    public void onClickClear(MenuItem menuItem){
        bmrDatabaseHelper.clearAllBMRData();
        clearPreference();
    }
}