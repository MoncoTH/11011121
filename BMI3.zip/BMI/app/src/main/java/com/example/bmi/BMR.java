package com.example.bmi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class BMR extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        Intent intent = getIntent();
        String result = intent.getStringExtra(MainActivity.BMI_MSG);
        String message;
        message = getString(R.string.BMRshow) + " " + result + " " + getString(R.string.Calories);
        TextView textView = (TextView) findViewById(R.id.BMRView);
        textView.setTextSize(25);
        textView.setText(message);
    }
//    LAB3
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_display_message, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Cheack");
        intent.putExtra(Intent.EXTRA_SUBJECT, R.id.BMRView);
        startActivity(Intent.createChooser(intent, "HAHAHA"));
        return super.onOptionsItemSelected(item);
    }
}