package com.example.earthquake;

import android.icu.text.SimpleDateFormat;
import android.location.Location;

import java.util.Date;
import java.util.Locale;

public class Quake {
    private Date date;
    private String details;
    private Location location;
    private double magnitude;
    private String link;
    private double depth;

    public Date getDate() { return date; }
    public String getDetails() { return details; }
    public Location getLocation() { return location; }
    public double getMagnitude() { return magnitude; }
    public String getLink() { return link; }
    public double getDepth(){ return depth;}

    public Quake(Date _d, String _det, Location _loc, double _mag, String _link, String getDepth) {
        date = _d;
        details = _det;
        location = _loc;
        magnitude = _mag;
        link = _link;
        depth = Double.parseDouble(getDepth);

    }
    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YY, HH.mm", Locale.US);
        String dateString = sdf.format(date);
        return dateString + ": " + magnitude + " (" + depth + " m. ) " + details;
    }
}
